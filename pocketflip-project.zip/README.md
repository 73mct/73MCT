# PocketFlip Android source ZIP

This is the PocketFlip Android project source package. You can upload this ZIP directly to GitHub; you do **not** need to extract it on your computer.

## GitHub ZIP-upload setup

1. In your empty GitHub repository, create `.github/workflows/build-apk.yml` and paste the workflow provided separately as `build-apk-from-zip.yml`.
2. Commit that workflow file first.
3. Upload this archive to the repository root and name the uploaded file exactly `pocketflip-project.zip`.
4. Commit the ZIP. The workflow will automatically extract it on the GitHub runner and build the debug APK.
5. Open **Actions**, open the successful run, and download the `PocketFlip-Android-APK` artifact.

The ZIP contains Android project source code, not a prebuilt APK.
