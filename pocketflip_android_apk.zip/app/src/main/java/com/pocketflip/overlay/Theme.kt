package com.pocketflip.overlay

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.widget.ImageView
import android.widget.LinearLayout
import android.view.ViewOutlineProvider

/**
 * User-customizable color theme shared by the app screens and the floating bubble.
 * Default = pure black & white. Colors are saved separately from trading data.
 */
object Theme {
    private const val PREFS_NAME = "pocketflip_theme"

    data class Slot(val key: String, val label: String, val defaultHex: String)

    val slots: List<Slot> = listOf(
        Slot("bg", "Background", "#000000"),
        Slot("card", "Cards / panel", "#0D0D0D"),
        Slot("border", "Borders", "#262626"),
        Slot("text", "Main text / accent", "#FFFFFF"),
        Slot("muted", "Muted text", "#8C8C8C"),
        Slot("buy", "Buy buttons", "#FFFFFF"),
        Slot("sell", "Sell buttons", "#FFFFFF"),
        Slot("profit", "Profit color", "#FFFFFF"),
        Slot("loss", "Loss color", "#9A9A9A")
    )

    val presets: LinkedHashMap<String, Map<String, String>> = linkedMapOf(
        "Black & White" to slots.associate { it.key to it.defaultHex },
        "B&W + Green/Red PnL" to slots.associate { it.key to it.defaultHex } +
            mapOf("profit" to "#22C55E", "loss" to "#EF4444"),
        "Paper (White)" to mapOf(
            "bg" to "#FFFFFF", "card" to "#F4F4F4", "border" to "#DADADA",
            "text" to "#000000", "muted" to "#6B6B6B",
            "buy" to "#000000", "sell" to "#000000",
            "profit" to "#000000", "loss" to "#6B6B6B"
        ),
        "Midnight" to mapOf(
            "bg" to "#05070D", "card" to "#0D111A", "border" to "#1F2937",
            "text" to "#F8FAFC", "muted" to "#94A3B8",
            "buy" to "#38BDF8", "sell" to "#F472B6",
            "profit" to "#34D399", "loss" to "#FB7185"
        )
    )

    private var prefs: SharedPreferences? = null
    private val hexMap = LinkedHashMap<String, String>()
    private val intMap = HashMap<String, Int>()

    /** Increments every time the theme changes so the bubble knows to rebuild itself. */
    @Volatile
    var version: Int = 0
        private set

    @Synchronized
    fun init(context: Context) {
        if (prefs != null) return
        prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        for (s in slots) {
            val saved = prefs?.getString(s.key, null)
            val hex = if (saved != null && parseHex(saved) != null) saved else s.defaultHex
            hexMap[s.key] = hex
            intMap[s.key] = parseHex(hex) ?: Color.BLACK
        }
    }

    fun parseHex(raw: String): Int? {
        val t = raw.trim()
        if (t.isEmpty()) return null
        val withHash = if (t.startsWith("#")) t else "#$t"
        return try {
            Color.parseColor(withHash)
        } catch (_: Throwable) {
            null
        }
    }

    @Synchronized
    fun applyColors(values: Map<String, String>) {
        val ed = prefs?.edit()
        for (s in slots) {
            val raw = values[s.key] ?: continue
            val parsed = parseHex(raw) ?: continue
            val hex = if (raw.trim().startsWith("#")) raw.trim() else "#" + raw.trim()
            hexMap[s.key] = hex
            intMap[s.key] = parsed
            ed?.putString(s.key, hex)
        }
        ed?.apply()
        version++
    }

    fun hexOf(key: String): String = hexMap[key] ?: "#000000"

    fun c(key: String): Int = intMap[key] ?: Color.MAGENTA

    val bg: Int get() = c("bg")
    val card: Int get() = c("card")
    val border: Int get() = c("border")
    val text: Int get() = c("text")
    val muted: Int get() = c("muted")
    val buy: Int get() = c("buy")
    val sell: Int get() = c("sell")
    val profit: Int get() = c("profit")
    val loss: Int get() = c("loss")

    fun pnlColor(value: Double): Int = if (value >= 0.0) profit else loss

    /** Readable text color (black or white) for something drawn on top of [background]. */
    fun onColor(background: Int): Int {
        val lum = (0.299 * Color.red(background) + 0.587 * Color.green(background) +
            0.114 * Color.blue(background)) / 255.0
        return if (lum > 0.55) Color.BLACK else Color.WHITE
    }

    fun alpha(color: Int, a: Int): Int =
        Color.argb(a.coerceIn(0, 255), Color.red(color), Color.green(color), Color.blue(color))

    fun box(fill: Int, stroke: Int, radiusPx: Int, strokePx: Int): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = radiusPx.toFloat()
            setColor(fill)
            if (strokePx > 0) setStroke(strokePx, stroke)
        }
    }

    fun circle(fill: Int, stroke: Int, strokePx: Int): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(fill)
            if (strokePx > 0) setStroke(strokePx, stroke)
        }
    }

    /** Round coin-image view (falls back to an empty circle until the picture loads). */
    fun avatar(context: Context, sizePx: Int, strokePx: Int): ImageView {
        return ImageView(context).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = circle(alpha(text, 0x22), border, strokePx)
            clipToOutline = true
            outlineProvider = ViewOutlineProvider.BACKGROUND
            layoutParams = LinearLayout.LayoutParams(sizePx, sizePx)
        }
    }
}
